document.addEventListener('DOMContentLoaded', function () {
  const toastTrigger = document.querySelectorAll('[data-bs-toggle="toast"]');
  toastTrigger.forEach(function (btn) {
    btn.addEventListener('click', function () {
      const target = document.querySelector(btn.dataset.bsTarget);
      if (target) {
        new bootstrap.Toast(target).show();
      }
    });
  });
});
